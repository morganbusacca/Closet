My Digital Closet (installable web app)

1. Upload this whole folder to a static host (Netlify Drop, GitHub Pages, Cloudflare Pages).
2. Open the https:// address on your phone.
3. iPhone: Share > Add to Home Screen. Android: menu > Install app.

Notes:
- It must be served over https (or localhost) for install and offline mode to work.
- Opening index.html straight from your files will work as a normal page but won't install.
- Your closet is stored in the browser on each device; clearing site data erases it.
- To ship an update, change the CACHE name in sw.js (e.g. closet-shell-v2).
